#!/usr/bin/env bash
# coded by ogcyb3r

WhereisF="font_output"

if [[ $1 ]]; then
  listdns=$(cat font_list.txt)
  for wan in $listdns; do
    UnableAre=$( (echo $1 | figlet -f usr/share/figlet/$wan | grep -E "Unable to open") 2>&1  )
    if [[ ! "$UnableAre"  ]]; then
      if [[ "$2" == "--save" ]]; then
        echo $1 | figlet -f usr/share/figlet/$wan >> $WhereisF/"$1".txt
      fi
      echo $1 | figlet -f usr/share/figlet/$wan
    fi
  done
  printf "\e[30;38;5;244mOutput example :

\e[30;48;5;118m  ┌────────────────────────────────────────┐
  │                                        │
  │       ▄▄                               │
  │       ██                               │
  │  ▄███▄██   ▄████▄   ██▄████▄   ▄████▄  │
  │ ██▀  ▀██  ██▀  ▀██  ██▀   ██  ██▄▄▄▄██ │
  │ ██    ██  ██    ██  ██    ██  ██▀▀▀▀▀▀ │
  │ ▀██▄▄███  ▀██▄▄██▀  ██    ██  ▀██▄▄▄▄█ │
  │   ▀▀▀ ▀▀    ▀▀▀▀    ▀▀    ▀▀    ▀▀▀▀▀  │
  │                                        │
  │                                        │
  └────────────────────────────────────────┘\e[0m

[ + ] \e[1;38;5;248mFile has been saved :\e[0m \e[1;38;5;79m$WhereisF/$1.txt\e[0m

  "
else
  clear
  printf "\e[30;38;5;244mOutput example :\e[30;48;5;110m
  ┌────────────────────────────────────────────────────────────┐
  │                                                            │
  │    ▄▄▄▄                                 ▄▄▄  ▄▄▄           │
  │   ██▀▀▀                         ██      ███  ███           │
  │ ███████    ▄████▄   ██▄████▄  ███████   ████████   ▄████▄  │
  │   ██      ██▀  ▀██  ██▀   ██    ██      ██ ██ ██  ██▄▄▄▄██ │
  │   ██      ██    ██  ██    ██    ██      ██ ▀▀ ██  ██▀▀▀▀▀▀ │
  │   ██      ▀██▄▄██▀  ██    ██    ██▄▄▄   ██    ██  ▀██▄▄▄▄█ │
  │   ▀▀        ▀▀▀▀    ▀▀    ▀▀     ▀▀▀▀   ▀▀    ▀▀    ▀▀▀▀▀  │
  │                                                            │
  │create your own appealing ASCII text banners from plain text│
  └────────────────────────────────────────────────────────────┘\e[0m

  \e[1;38;5;255mHow to use :\e[0m

  \e[1;38;5;119m[ 1 ] \e[1;38;5;110m$0 fontMe           | \e[1;38;5;145m( print on terminal only )
  \e[1;38;5;119m[ 2 ] \e[1;38;5;110m$0 fontMe --save    | \e[1;38;5;145m( print on terminal and Save it as text ) \e[0m


"
fi
